package com.bluebigfish.app

import android.app.Activity
import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var countView: TextView
    private lateinit var maidView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(237, 243, 255)
        window.navigationBarColor = Color.rgb(237, 243, 255)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(237, 243, 255))
        }
        val content = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        maidView = ImageView(this).apply {
            setImageResource(R.drawable.maid)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "點擊藍色大肥魚"
            isClickable = true
            isFocusable = true
            setOnClickListener { onMaidTapped() }
        }
        content.addView(maidView, android.widget.LinearLayout.LayoutParams(dp(260), dp(260)))
        countView = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.rgb(36, 63, 112))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        content.addView(countView, android.widget.LinearLayout.LayoutParams(-2, -2))
        root.addView(content, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        setContentView(root)
        refreshCount()
    }

    private fun onMaidTapped() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = todayKey()
        val savedDay = prefs.getString(KEY_DAY, null)
        val count = if (savedDay == today) prefs.getInt(KEY_COUNT, 0) + 1 else 1
        prefs.edit().putString(KEY_DAY, today).putInt(KEY_COUNT, count)
            .apply()
        countView.text = "$count 次"
        animateMaid()
        playSqueak()
        MaidWidgetProvider.refreshAll(this)
    }

    private fun refreshCount() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = todayKey()
        val savedDay = prefs.getString(KEY_DAY, null)
        val count = if (savedDay == today) prefs.getInt(KEY_COUNT, 0) else 0
        if (savedDay != today) prefs.edit().putString(KEY_DAY, today).putInt(KEY_COUNT, 0).apply()
        countView.text = "$count 次"
        MaidWidgetProvider.scheduleNextMidnight(this)
        MaidWidgetProvider.refreshAll(this)
    }

    override fun onResume() {
        super.onResume()
        if (::countView.isInitialized) refreshCount()
    }

    private fun animateMaid() {
        maidView.clearAnimation()
        val squash = ScaleAnimation(
            1f, 1.10f, 1f, 0.82f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.82f
        ).apply {
            duration = 105
            repeatCount = 1
            repeatMode = Animation.REVERSE
            interpolator = android.view.animation.OvershootInterpolator(1.3f)
        }
        maidView.startAnimation(squash)
    }

    private fun playSqueak() {
        try {
            val player = MediaPlayer.create(this, R.raw.squeak) ?: return
            player.setOnCompletionListener { it.release() }
            player.setOnErrorListener { mp, _, _ -> mp.release(); true }
            player.start()
        } catch (_: Exception) { }
    }

    private fun pill(fill: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(28).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun todayKey() = SimpleDateFormat("yyyy-MM-dd", Locale.TAIWAN).format(Date())

    companion object {
        private const val PREFS = "maid_widget_prefs"
        private const val KEY_DAY = "day"
        private const val KEY_COUNT = "count"
    }
}
