package com.bluebigfish.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MaidWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refreshAll(context)
        scheduleNextMidnight(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TAP -> {
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val today = todayKey()
                val savedDay = prefs.getString(KEY_DAY, null)
                val count = if (savedDay == today) prefs.getInt(KEY_COUNT, 0) + 1 else 1
                prefs.edit()
                    .putString(KEY_DAY, today)
                    .putInt(KEY_COUNT, count)
                    .apply()
                playSqueak(context)
                // Briefly change only the maid image; the white tile and labels remain still.
                showMaidSquish(context)
                Handler(Looper.getMainLooper()).postDelayed({ refreshAll(context) }, 140L)
            }
            ACTION_RESET -> {
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                prefs.edit().putString(KEY_DAY, todayKey()).putInt(KEY_COUNT, 0).apply()
                refreshAll(context)
                scheduleNextMidnight(context)
            }
        }
    }

    companion object {
        const val ACTION_TAP = "com.bluebigfish.app.ACTION_TAP"
        const val ACTION_RESET = "com.bluebigfish.app.ACTION_RESET"
        private const val PREFS = "maid_widget_prefs"
        private const val KEY_DAY = "day"
        private const val KEY_COUNT = "count"

        fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.TAIWAN).format(Date())

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, MaidWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val today = todayKey()
            val savedDay = prefs.getString(KEY_DAY, null)
            val count = if (savedDay == today) prefs.getInt(KEY_COUNT, 0) else 0
            if (savedDay != today) {
                prefs.edit().putString(KEY_DAY, today).putInt(KEY_COUNT, 0).apply()
            }
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.maid_widget)
                views.setTextViewText(R.id.count_text, "$count")
                val tapIntent = Intent(context, MaidWidgetProvider::class.java).apply { action = ACTION_TAP }
                val tapPending = PendingIntent.getBroadcast(
                    context, id, tapIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setImageViewResource(R.id.maid_image, R.drawable.maid)
                views.setOnClickPendingIntent(R.id.maid_image, tapPending)
                manager.updateAppWidget(id, views)
            }
        }

        private fun showMaidSquish(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, MaidWidgetProvider::class.java)
            manager.getAppWidgetIds(component).forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.maid_widget)
                views.setImageViewResource(R.id.maid_image, R.drawable.maid_squish)
                manager.partiallyUpdateAppWidget(id, views)
            }
        }

        fun scheduleNextMidnight(context: Context) {
            val next = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 2)
                set(Calendar.MILLISECOND, 0)
            }
            val intent = Intent(context, MaidWidgetProvider::class.java).apply { action = ACTION_RESET }
            val pending = PendingIntent.getBroadcast(
                context, 909, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            // Inexact allow-while-idle alarm avoids requiring the special exact-alarm permission.
            // Android may defer it slightly during Doze; the date is also checked on every tap/update.
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
        }

        private fun playSqueak(context: Context) {
            try {
                val player = MediaPlayer.create(context, R.raw.squeak) ?: return
                player.setOnCompletionListener { it.release() }
                player.setOnErrorListener { mp, _, _ -> mp.release(); true }
                player.start()
            } catch (_: Exception) {
                // A failed sound must never prevent the widget counter from updating.
            }
        }
    }
}
